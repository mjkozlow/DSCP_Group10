#!/bin/bash

rm -rf by_location/
rm -rf by_time/
rm fileInputList
rm chicago_community_areas_2025.csv
rm *.csv
